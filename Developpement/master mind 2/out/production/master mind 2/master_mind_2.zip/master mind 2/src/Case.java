/**
 * Created by marti on 19/12/2017.
 */
public class Case {
    Boolean trouvé;
    String couleur;

    Case()
    {
        trouvé=false;
        couleur="";
    }

    void setTrouvé(String _couleur)
    {
        trouvé=true;
        couleur=_couleur;
    }

    boolean getTrouvé(){
        return trouvé;
    }

    String getCouleur(){
        return couleur;
    }



}
